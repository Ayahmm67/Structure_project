/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee;

/**
 *
 * @author user
 */
public class Node {
 EmployeeInfo data;
 Node next;
 public Node(EmployeeInfo Employee){
 this.data = Employee;
 next = null;
 }
    
}
